﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Azure.Data.Tables;
using CloudDevPoe.Models;

namespace CloudDevPoe.Controllers
{
    public class ProductController(IConfiguration configuration) : Controller
    {
        private readonly string _tableConnectionString = configuration.GetConnectionString("AzureStorage");
        private readonly string _tableName = "ProductDetails";

        public async Task<IActionResult> Index()
        {
            var tableServiceClient = new TableServiceClient(_tableConnectionString);
            var tableClient = tableServiceClient.GetTableClient(_tableName);
            await tableClient.CreateIfNotExistsAsync();

            var products = tableClient.Query<Product>(filter: $"PartitionKey eq 'Products'");

            return View(products);
        }
    }
}
