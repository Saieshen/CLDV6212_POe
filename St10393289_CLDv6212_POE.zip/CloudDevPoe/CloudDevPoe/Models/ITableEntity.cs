﻿namespace CloudDevPoe.Models.YourNamespace.Models
{
    public interface ITableEntity
    {
    }
}